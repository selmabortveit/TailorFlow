import argparse
import calendar
import json
import secrets
import sqlite3
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

# Python can import pure-Python packages directly from a ZIP. Bundling them
# lets the tutor run this project without installing Flask or its dependencies.
ROOT = Path(__file__).resolve().parent
if (ROOT / "libraries.zip").is_file():
    sys.path.insert(0, str(ROOT / "libraries.zip"))

from flask import Flask, Response, abort, flash, redirect, render_template, request, session, url_for

from calendar_feed import (CalendarError, CalendarSettings, calendar_packages_available,
                           download_feed, parse_feed)
from database import (APPOINTMENT_FIELDS, CUSTOMER_FIELDS, ORDER_FIELDS, STOCK_FIELDS, ShopRepository)
from models import OrderFinance, measurement, status_tone, valid_date

CLOSED = ("Completed", "Cancelled", "Returned")


def create_app(config=None):
    app = Flask(__name__, instance_path=str(ROOT / "instance"))
    app.config.update(DATABASE=str(ROOT / "instance" / "tailorflow.sqlite3"),
                      CALENDAR_DIR=str(ROOT / "instance"), SEED_DEMO=True,
                      MAX_CONTENT_LENGTH=1024 * 1024, SESSION_COOKIE_SAMESITE="Lax")
    if config:
        app.config.update(config)
    private_dir = Path(app.config["CALENDAR_DIR"])
    private_dir.mkdir(parents=True, exist_ok=True)
    if not app.config.get("SECRET_KEY"):
        key_file = private_dir / "session.key"
        if not key_file.exists():
            key_file.write_bytes(secrets.token_bytes(32))
            key_file.chmod(0o600)
        app.config["SECRET_KEY"] = key_file.read_bytes()
    options = json.loads((ROOT / "options.json").read_text(encoding="utf-8"))
    app.jinja_env.globals["status_tone"] = status_tone
    shop_tz = ZoneInfo(options["timezone"])
    repo = ShopRepository(app.config["DATABASE"])
    repo.initialise(app.config["SEED_DEMO"])
    app.extensions["shop"] = repo
    settings = CalendarSettings(private_dir / "calendar.json")
    cache_path = private_dir / "google-calendar.ics"

    def today():
        return datetime.now(shop_tz).date()

    def csrf_token():
        if "csrf" not in session:
            session["csrf"] = secrets.token_hex(24)
        return session["csrf"]

    @app.before_request
    def check_csrf():
        if request.method == "POST":
            expected = session.get("csrf", "")
            if not expected or not secrets.compare_digest(expected, request.form.get("csrf_token", "")):
                abort(400, description="This form expired. Reload the page and try again.")

    @app.after_request
    def response_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        if request.endpoint != "static":
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.context_processor
    def shared_values():
        return dict(options=options, today=today(), csrf_token=csrf_token, status_tone=status_tone)

    @app.template_filter("money")
    def money(cents):
        cents = int(cents or 0)
        return f"${cents // 100:,}.{cents % 100:02d}"

    @app.template_filter("date")
    def display_date(value, long=False):
        if not value:
            return "To be agreed"
        day = date.fromisoformat(str(value)[:10])
        return f"{day.day} {day:%B %Y}" if long else f"{day.day} {day:%b %Y}"

    @app.template_filter("stamp")
    def display_stamp(value):
        stamp = datetime.fromisoformat(value).replace(tzinfo=timezone.utc).astimezone(shop_tz)
        return f"{stamp.day} {stamp:%b, %I:%M %p}"

    @app.template_filter("form_date")
    def form_date(value):
        """Unambiguous day/month/year dates for the paper hire form."""
        return date.fromisoformat(value).strftime("%d/%m/%Y") if value else "To be agreed"

    @app.template_filter("initials")
    def initials(name):
        return "".join(word[0] for word in name.split()[:2]).upper()

    def require_customer(record_id):
        return repo.customer(record_id) or abort(404)

    def require_order(record_id):
        return repo.order(record_id) or abort(404)

    def read_fields(fields):
        return {field: request.form.get(field, "").strip()[:5000 if field == "notes" else 300] for field in fields}

    def calendar_entries(beginning, ending):
        """Combine local appointments, order dates and optional cached Google entries."""
        entries = []
        for appointment in repo.appointments():
            if beginning.isoformat() <= appointment["day"] < ending.isoformat():
                entries.append(dict(day=appointment["day"], time=appointment["start_time"],
                                    end_time=appointment["end_time"], title=appointment["title"],
                                    kind="appointment", source="Local", uid=f"appointment-{appointment['id']}",
                                    url=url_for("appointment_form", record_id=appointment["id"])))
        for order in repo.orders():
            if order["status"] == "Cancelled":
                continue
            for field, kind, label in (("pickup_date", "pickup", "Pickup"), ("return_date", "return", "Return")):
                if order[field] and beginning.isoformat() <= order[field] < ending.isoformat():
                    entries.append(dict(day=order[field], time="", title=f"{label} · {order['customer_name']}",
                                        kind=kind, source="Order", uid=f"order-{order['id']}-{kind}",
                                        url=url_for("order_detail", record_id=order["id"])))
        connection_error = ""
        try:
            connection = settings.load()
            if connection["url"] and cache_path.exists():
                for event in parse_feed(cache_path.read_bytes(), beginning, ending, connection["timezone"]):
                    day = max(beginning, event.start.date())
                    while day < ending and event.occurs_on(day):
                        entries.append(dict(day=day.isoformat(), time="" if event.all_day else event.time_label(day),
                                            title=event.title, kind="appointment", source="Google Calendar", url=""))
                        day += timedelta(days=1)
        except CalendarError as error:
            connection_error = str(error)
        return sorted(entries, key=lambda item: (item["day"], item["time"], item["title"])), connection_error

    @app.get("/")
    def dashboard():
        all_orders = repo.orders()
        active = [order for order in all_orders if order["status"] not in CLOSED]
        upcoming = sorted([order for order in active if order["pickup_date"] and order["status"] != "Collected"],
                          key=lambda order: order["pickup_date"])
        entries, _ = calendar_entries(today(), today() + timedelta(days=7))
        appointments = [entry for entry in entries if entry["kind"] == "appointment"]
        stock = repo.stock()
        stats = dict(open=len(active), ready=sum(o["status"] == "Ready for pickup" for o in active),
                     soon=sum(today().isoformat() <= o["pickup_date"] <= (today() + timedelta(days=14)).isoformat() for o in upcoming),
                     outstanding=sum(o["finance"].balance_cents for o in active),
                     out_of_stock=sum(item["available"] == 0 for item in stock))
        returns = sorted([o for o in active if o["service"] == "Formal hire" and o["status"] == "Collected" and o["return_date"]],
                         key=lambda order: order["return_date"])
        workflow = {status: sum(o["status"] == status for o in active) for status in options["statuses"][:6]}
        return render_template("dashboard.html", nav="dashboard", title="Dashboard", stats=stats,
                               upcoming=upcoming[:5], appointments=appointments, returns=returns[:4],
                               workflow=workflow, stock_count=len(stock))

    @app.get("/clients")
    def clients():
        search = request.args.get("q", "").strip()
        return render_template("clients.html", nav="clients", title="Clients", search=search, customers=repo.customers(search))

    @app.route("/clients/new", methods=["GET", "POST"])
    @app.route("/clients/<int:record_id>/edit", methods=["GET", "POST"])
    def client_form(record_id=None):
        values = require_customer(record_id) if record_id else {}
        error = ""
        if request.method == "POST":
            values = read_fields(CUSTOMER_FIELDS)
            try:
                if not values["name"]:
                    raise ValueError("Enter the client's name.")
                for field in ("neck_cm", "chest_cm", "waist_cm"):
                    values[field] = measurement(values[field], field.split("_")[0].title())
                if values["email"] and ("@" not in values["email"] or " " in values["email"]):
                    raise ValueError("Enter a valid email address, or leave it blank.")
                record_id = repo.save_customer(values, record_id)
                flash("Client record saved.", "success")
                return redirect(url_for("client_detail", record_id=record_id))
            except (ValueError, sqlite3.IntegrityError) as exception:
                error = str(exception)
        return render_template("client_form.html", nav="clients", title="Edit client" if record_id else "New consultation",
                               values=values, error=error, record_id=record_id), 400 if error else 200

    @app.get("/clients/<int:record_id>")
    def client_detail(record_id):
        customer = require_customer(record_id)
        orders = repo.orders(record_id)
        profile = dict(customer)
        if orders:
            for field in ("jacket_size", "trouser_size", "shirt_size", "shirt_brand", "suit_brand", "style", "colour", "occasion"):
                profile[field] = profile[field] or orders[0][field]
        return render_template("client_detail.html", nav="clients", title=customer["name"], customer=customer,
                               profile=profile, orders=orders)

    @app.get("/orders")
    def orders():
        search, status, service = (request.args.get(key, "").strip() for key in ("q", "status", "service"))
        rows = repo.orders()
        if search:
            rows = [o for o in rows if search.casefold() in " ".join(str(o[k]) for k in ("order_no", "customer_name", "garment", "occasion")).casefold()]
        if status == "Open":
            rows = [o for o in rows if o["status"] not in CLOSED]
        elif status:
            rows = [o for o in rows if o["status"] == status]
        if service:
            rows = [o for o in rows if o["service"] == service]
        return render_template("orders.html", nav="orders", title="Orders", orders=rows, search=search, status=status, service=service)

    @app.route("/orders/new", methods=["GET", "POST"])
    @app.route("/orders/<int:record_id>/edit", methods=["GET", "POST"])
    def order_form(record_id=None):
        values = require_order(record_id) if record_id else dict(visit_date=today().isoformat(), status="New consultation", service="Formal hire")
        if not record_id and request.args.get("customer_id", "").isdigit():
            customer = require_customer(int(request.args["customer_id"]))
            values.update({field: customer[field] for field in ("suit_brand", "style", "colour", "occasion", "jacket_size", "trouser_size", "shirt_size", "shirt_brand")})
            values["customer_id"] = customer["id"]
        values["price"] = f"{values.get('total_cents', 0) / 100:.2f}"
        values["initial_paid"] = "0.00"
        error = ""
        if request.method == "POST":
            values = read_fields(ORDER_FIELDS)
            values.update(price=request.form.get("price", ""), initial_paid=request.form.get("initial_paid", "0"))
            try:
                if not values["customer_id"].isdigit() or not repo.customer(int(values["customer_id"])):
                    raise ValueError("Choose an existing client first.")
                if values["status"] not in options["statuses"] or values["service"] not in options["services"]:
                    raise ValueError("Choose a valid service and status.")
                for field in ("visit_date", "pickup_date", "return_date"):
                    values[field] = valid_date(values[field], field.replace("_", " "), required=field == "visit_date")
                if values["return_date"] and values["pickup_date"] and values["return_date"] < values["pickup_date"]:
                    raise ValueError("The return date cannot be before pickup.")
                values["garment"] = values["garment"] or " ".join(part for part in (values["colour"], values["suit_brand"], "suit") if part)
                values["total_cents"] = OrderFinance.to_cents(values["price"], "Total price")
                paid = OrderFinance.to_cents(values["initial_paid"], "Amount paid") if not record_id else 0
                record_id = repo.save_order(values, record_id, paid)
                flash("Order saved.", "success")
                return redirect(url_for("order_detail", record_id=record_id))
            except (ValueError, sqlite3.IntegrityError) as exception:
                error = str(exception)
        return render_template("order_form.html", nav="orders", title="Edit order" if record_id else "New order",
                               values=values, customers=repo.customers(), record_id=record_id, error=error), 400 if error else 200

    @app.get("/orders/<int:record_id>")
    def order_detail(record_id):
        order = require_order(record_id)
        return render_template("order_detail.html", nav="orders", title=order["garment"], order=order,
                               history=repo.query("SELECT * FROM order_events WHERE order_id = ? ORDER BY id DESC", (record_id,)),
                               payments=repo.query("SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC", (record_id,)))

    @app.get("/orders/<int:record_id>/print")
    def print_order_form(record_id):
        """Print one saved order; never substitute a client's newer garment sizes."""
        order = require_order(record_id)
        customer = require_customer(order["customer_id"])
        return render_template("hire_form.html", order=order, customer=customer)

    @app.post("/orders/<int:record_id>/status")
    def order_status(record_id):
        require_order(record_id)
        status = request.form.get("status", "")
        if status not in options["statuses"]:
            abort(400, description="Choose a valid order status.")
        repo.set_status(record_id, status)
        flash(f"Status changed to {status.lower()}.", "success")
        return redirect(url_for("order_detail", record_id=record_id))

    @app.post("/orders/<int:record_id>/payment")
    def payment(record_id):
        require_order(record_id)
        try:
            amount = OrderFinance.to_cents(request.form.get("amount", ""))
            if amount <= 0:
                raise ValueError("Enter a payment greater than zero.")
            repo.record_payment(record_id, amount, request.form.get("note", "").strip()[:300])
            flash("Payment recorded.", "success")
        except (ValueError, sqlite3.IntegrityError) as error:
            flash(str(error), "error")
        return redirect(url_for("order_detail", record_id=record_id))

    @app.get("/stock")
    def stock():
        items = repo.stock()
        stats = dict(items=len(items), hire=sum(i["quantity"] for i in items if i["kind"] == "Hire"),
                     out=sum(i["quantity_out"] for i in items), empty=sum(i["available"] == 0 for i in items))
        search, kind, category = (request.args.get(key, "").strip() for key in ("q", "kind", "category"))
        if search:
            items = [i for i in items if search.casefold() in " ".join(str(i[k]) for k in ("name", "barcode", "brand", "size", "colour")).casefold()]
        if kind:
            items = [i for i in items if i["kind"] == kind]
        if category:
            items = [i for i in items if i["category"] == category]
        return render_template("stock.html", nav="stock", title="Stock", items=items, stats=stats,
                               search=search, kind=kind, category=category)

    @app.route("/stock/new", methods=["GET", "POST"])
    @app.route("/stock/<int:record_id>/edit", methods=["GET", "POST"])
    def stock_form(record_id=None):
        values = (repo.stock_item(record_id) or abort(404)) if record_id else dict(kind="Hire", quantity=1, quantity_out=0)
        values["price"] = f"{values.get('price_cents', 0) / 100:.2f}"
        error = ""
        if request.method == "POST":
            values = read_fields(STOCK_FIELDS)
            values["price"] = request.form.get("price", "")
            try:
                if not values["barcode"] or not values["name"]:
                    raise ValueError("Enter the item's name and barcode or stock code.")
                if values["kind"] not in ("Hire", "Sale") or values["category"] not in options["categories"]:
                    raise ValueError("Choose a valid category and stock type.")
                for field in ("quantity", "quantity_out"):
                    if not values[field].isdigit():
                        raise ValueError("Stock quantities must be whole numbers, zero or above.")
                    values[field] = int(values[field])
                if values["quantity_out"] > values["quantity"] or (values["kind"] == "Sale" and values["quantity_out"]):
                    raise ValueError("Pieces out must not exceed the total. Sale items cannot be on hire.")
                values["price_cents"] = OrderFinance.to_cents(values["price"], "Price")
                repo.save_stock(values, record_id)
                flash("Stock item saved.", "success")
                return redirect(url_for("stock"))
            except ValueError as exception:
                error = str(exception)
            except sqlite3.IntegrityError:
                error = "That stock code is already in use. Choose a different code."
        return render_template("stock_form.html", nav="stock", title="Edit stock item" if record_id else "Add stock item",
                               values=values, record_id=record_id, error=error), 400 if error else 200

    @app.post("/stock/<int:record_id>/action")
    def stock_action(record_id):
        if not repo.stock_item(record_id):
            abort(404)
        try:
            repo.stock_action(record_id, request.form.get("action", ""))
            flash("Stock quantity updated.", "success")
        except ValueError as error:
            flash(str(error), "error")
        return redirect(url_for("stock", q=request.form.get("q", ""), kind=request.form.get("kind", ""), category=request.form.get("category", "")))

    @app.get("/calendar")
    def calendar_page():
        try:
            chosen = date.fromisoformat(request.args.get("month", today().strftime("%Y-%m")) + "-01")
            if not 1900 <= chosen.year <= 2100:
                raise ValueError
        except ValueError:
            chosen = today().replace(day=1)
        weeks = calendar.Calendar(firstweekday=0).monthdatescalendar(chosen.year, chosen.month)
        entries, error = calendar_entries(weeks[0][0], weeks[-1][-1] + timedelta(days=1))
        try:
            connection = settings.load()
        except CalendarError as exception:
            connection = {"url": ""}
            error = str(exception)
        refreshed = datetime.fromtimestamp(cache_path.stat().st_mtime, shop_tz).strftime("%d %b, %I:%M %p") if cache_path.exists() else ""
        return render_template("calendar.html", nav="calendar", title="Calendar", month=chosen, weeks=weeks,
                               entries=entries, connection=bool(connection["url"]), calendar_error=error, refreshed=refreshed,
                               previous=(chosen - timedelta(days=1)).strftime("%Y-%m"),
                               following=(chosen.replace(day=28) + timedelta(days=4)).strftime("%Y-%m"))

    @app.route("/appointments/new", methods=["GET", "POST"])
    @app.route("/appointments/<int:record_id>/edit", methods=["GET", "POST"])
    def appointment_form(record_id=None):
        values = next((a for a in repo.appointments() if a["id"] == record_id), None) if record_id else dict(day=request.args.get("day", today().isoformat()), start_time="10:00", end_time="10:30")
        if values is None:
            abort(404)
        error = ""
        if request.method == "POST":
            values = read_fields(APPOINTMENT_FIELDS)
            try:
                if not values["title"]:
                    raise ValueError("Enter an appointment title.")
                values["day"] = valid_date(values["day"], "appointment date", required=True)
                for field in ("start_time", "end_time"):
                    try:
                        values[field] = datetime.strptime(values[field], "%H:%M").strftime("%H:%M")
                    except ValueError:
                        raise ValueError("Enter valid start and end times.") from None
                if values["end_time"] <= values["start_time"]:
                    raise ValueError("End time must be after the start time.")
                if values["customer_id"] and (not values["customer_id"].isdigit() or not repo.customer(int(values["customer_id"]))):
                    raise ValueError("Choose a valid client, or leave the appointment unlinked.")
                values["customer_id"] = int(values["customer_id"]) if values["customer_id"] else None
                repo.save_appointment(values, record_id)
                flash("Appointment saved.", "success")
                return redirect(url_for("calendar_page", month=values["day"][:7]))
            except (ValueError, sqlite3.IntegrityError) as exception:
                error = str(exception)
        return render_template("appointment_form.html", nav="calendar", title="Edit appointment" if record_id else "New appointment",
                               values=values, customers=repo.customers(), record_id=record_id, error=error), 400 if error else 200

    def refresh_google(url, timezone_name):
        if not calendar_packages_available():
            raise CalendarError("Calendar support is not installed. Follow the optional calendar setup in README.md.")
        content = download_feed(url)
        parse_feed(content, today(), today() + timedelta(days=7), timezone_name)
        settings.save(url, timezone_name)
        temporary = cache_path.with_suffix(".tmp")
        temporary.write_bytes(content)
        temporary.chmod(0o600)
        temporary.replace(cache_path)

    @app.route("/calendar/connect", methods=["GET", "POST"])
    def calendar_connect():
        error = ""
        if request.method == "POST":
            try:
                refresh_google(request.form.get("url", "").strip(), options["timezone"])
                flash("Google Calendar connected. Appointments are shown from its read-only feed.", "success")
                return redirect(url_for("calendar_page"))
            except (CalendarError, OSError) as exception:
                error = str(exception) if isinstance(exception, CalendarError) else "Could not save the calendar connection. Check file permissions."
        return render_template("calendar_connect.html", nav="calendar", title="Connect Google Calendar", error=error), 400 if error else 200

    @app.post("/calendar/refresh")
    def calendar_refresh():
        try:
            connection = settings.load()
            refresh_google(connection["url"], connection["timezone"])
            flash("Google Calendar refreshed.", "success")
        except (CalendarError, OSError) as error:
            flash(str(error) if isinstance(error, CalendarError) else "The calendar cache could not be saved.", "error")
        return redirect(url_for("calendar_page"))

    @app.post("/calendar/disconnect")
    def calendar_disconnect():
        settings.save("", options["timezone"])
        cache_path.unlink(missing_ok=True)
        flash("Google Calendar disconnected. Your local appointments are still here.", "success")
        return redirect(url_for("calendar_page"))

    @app.get("/calendar/export")
    def calendar_export():
        # Export local appointments and order dates, not copies of Google's entries.
        try:
            beginning = date.fromisoformat(request.args.get("month", today().strftime("%Y-%m")) + "-01")
        except ValueError:
            abort(400)
        ending = (beginning.replace(day=28) + timedelta(days=4)).replace(day=1)
        entries, _ = calendar_entries(beginning, ending)
        return Response(make_ical([e for e in entries if e["source"] != "Google Calendar"], shop_tz),
                        mimetype="text/calendar", headers={"Content-Disposition": f'attachment; filename="tailorflow-{beginning:%Y-%m}.ics"'})

    @app.route("/<kind>/<int:record_id>/delete", methods=["GET", "POST"])
    def delete_record(kind, record_id):
        handlers = {
            "clients": (repo.customer, repo.delete_customer, "clients", "name"),
            "orders": (repo.order, repo.delete_order, "orders", "garment"),
            "stock": (repo.stock_item, repo.delete_stock, "stock", "name"),
            "appointments": (lambda i: next((a for a in repo.appointments() if a["id"] == i), None), repo.delete_appointment, "calendar_page", "title"),
        }
        if kind not in handlers:
            abort(404)
        get_record, remove, destination, label = handlers[kind]
        record = get_record(record_id) or abort(404)
        error = ""
        if request.method == "POST":
            try:
                remove(record_id)
                flash("Record deleted.", "success")
                return redirect(url_for(destination))
            except sqlite3.IntegrityError:
                error = "This client has orders. Keep the client to preserve those records."
            except ValueError as exception:
                error = str(exception)
        return render_template("delete.html", nav=kind if kind != "appointments" else "calendar", title="Delete record",
                               label=record[label], kind=kind, error=error, back=url_for(destination)), 400 if error else 200

    @app.get("/export.json")
    def export_json():
        return Response(json.dumps(repo.backup(), indent=2, ensure_ascii=False), mimetype="application/json",
                        headers={"Content-Disposition": f'attachment; filename="tailorflow-{today()}.json"'})

    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(413)
    def page_error(error):
        return render_template("error.html", title="Page unavailable", error=error), error.code

    return app


def make_ical(entries, shop_tz):
    """Create a portable .ics file using the standard library only."""
    def escape(text):
        return text.replace("\\", "\\\\").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;")

    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//TailorFlow//Local Calendar//EN", "CALSCALE:GREGORIAN"]
    for entry in entries:
        lines += ["BEGIN:VEVENT", f"UID:{entry['uid']}@tailorflow.local", f"DTSTAMP:{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}", f"SUMMARY:{escape(entry['title'])}"]
        day = date.fromisoformat(entry["day"])
        if entry["time"]:
            for key, time_value in (("DTSTART", entry["time"]), ("DTEND", entry["end_time"])):
                stamp = datetime.fromisoformat(f"{entry['day']}T{time_value}").replace(tzinfo=shop_tz).astimezone(timezone.utc)
                lines.append(f"{key}:{stamp:%Y%m%dT%H%M%SZ}")
        else:
            lines += [f"DTSTART;VALUE=DATE:{day:%Y%m%d}", f"DTEND;VALUE=DATE:{day + timedelta(days=1):%Y%m%d}"]
        lines.append("END:VEVENT")
    lines.append("END:VCALENDAR")
    folded = []
    for line in lines:
        part = ""
        for character in line:
            if len((part + character).encode("utf-8")) > 74:
                folded.append(part)
                part = " "
            part += character
        folded.append(part)
    return "\r\n".join(folded) + "\r\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run TailorFlow on this computer.")
    parser.add_argument("--port", type=int, default=5001)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--empty", action="store_true", help="Start a new database without the fictional demo records.")
    arguments = parser.parse_args()
    application = create_app({"SEED_DEMO": not arguments.empty})
    application.run(host=arguments.host, port=arguments.port, debug=False)
