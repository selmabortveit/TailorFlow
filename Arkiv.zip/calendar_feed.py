"""Optional, view-only Google Calendar feed support.

Only this module uses the optional calendar packages. The shop still works
offline without a calendar connection. app.py fetches the feed only when the
user connects or refreshes it; ordinary page requests use the saved cache.
"""

import importlib.util
import json
import os
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


class CalendarError(Exception):
    """A readable error that never exposes a private calendar address."""


def calendar_packages_available():
    return all(importlib.util.find_spec(name) is not None
               for name in ("icalendar", "recurring_ical_events"))


def validate_feed_url(url):
    text = url.strip()
    try:
        parsed = urlparse(text)
        valid = (parsed.scheme == "https" and parsed.hostname == "calendar.google.com"
                 and parsed.port in (None, 443) and not parsed.username and not parsed.password
                 and parsed.path.startswith("/calendar/ical/") and parsed.path.endswith(".ics")
                 and not parsed.fragment)
    except ValueError:
        valid = False
    if not valid:
        raise CalendarError("Paste the iCal (.ics) address from Google Calendar's Integrate calendar settings.")
    return text


def calendar_timezone(name):
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        raise CalendarError("Unknown timezone. Use Australia/Sydney, or install the optional calendar packages.") from None


class GoogleOnlyRedirects(HTTPRedirectHandler):
    def redirect_request(self, request, file, code, message, headers, new_url):
        validate_feed_url(new_url)
        return super().redirect_request(request, file, code, message, headers, new_url)


def download_feed(url):
    """Fetch a Google feed with a timeout and a bounded response size."""
    address = validate_feed_url(url)
    try:
        opener = build_opener(GoogleOnlyRedirects())
        request = Request(address, headers={"User-Agent": "TailorFlow/2.0"})
        with opener.open(request, timeout=12) as response:
            limit = 10 * 1024 * 1024
            content = response.read(limit + 1)
        if len(content) > limit:
            raise CalendarError("The calendar feed is too large to load. Try a smaller calendar.")
        if b"BEGIN:VCALENDAR" not in content[:2048]:
            raise CalendarError("Google did not return a calendar feed. Check the iCal address.")
        return content
    except (HTTPError, URLError, OSError, TimeoutError):
        raise CalendarError("Could not load Google Calendar. Check your internet connection and iCal address.") from None


@dataclass
class CalendarEvent:
    event_id: str
    title: str
    start: datetime
    end: datetime
    all_day: bool = False
    source: str = "Google Calendar"
    location: str = ""

    def occurs_on(self, day):
        beginning = datetime.combine(day, time.min, self.start.tzinfo)
        ending = beginning + timedelta(days=1)
        return self.start < ending and self.end > beginning

    def time_label(self, day):
        if self.all_day:
            return "ALL DAY"
        if self.start.date() < day:
            return "ONGOING"
        return self.start.strftime("%H:%M")


def parse_feed(content, start_date, end_date, timezone_name="Australia/Sydney"):
    """Expand recurrences, exceptions and moved events in a chosen date range."""
    if not calendar_packages_available():
        raise CalendarError("Install calendar support: python3 -m pip install -r requirements-calendar.txt")
    import icalendar
    import recurring_ical_events

    tz = calendar_timezone(timezone_name)
    beginning = datetime.combine(start_date, time.min, tz)
    ending = datetime.combine(end_date, time.min, tz)
    try:
        if b"BEGIN:VCALENDAR" not in content[:2048]:
            raise ValueError
        calendar = icalendar.Calendar.from_ical(content)
        instances = recurring_ical_events.of(calendar).between(beginning, ending)
        events = []
        for item in instances:
            if str(item.get("STATUS", "")).upper() == "CANCELLED":
                continue
            raw_start = item.decoded("DTSTART")
            all_day = isinstance(raw_start, date) and not isinstance(raw_start, datetime)
            raw_end = item.decoded("DTEND", None)
            if raw_end is None:
                raw_end = raw_start + item.decoded("DURATION", timedelta(days=1) if all_day else timedelta(minutes=1))

            def in_shop_timezone(value):
                if isinstance(value, datetime):
                    return value.replace(tzinfo=tz) if value.tzinfo is None else value.astimezone(tz)
                return datetime.combine(value, time.min, tz)

            start = in_shop_timezone(raw_start)
            end = in_shop_timezone(raw_end)
            if end <= start:
                end = start + timedelta(minutes=1)
            if start < ending and end > beginning:
                events.append(CalendarEvent(
                    event_id=f"{item.get('UID', '')}:{start.isoformat()}",
                    title=str(item.get("SUMMARY", "Appointment")), start=start, end=end,
                    all_day=all_day, location=str(item.get("LOCATION", "")),
                ))
        return sorted(events, key=lambda event: (event.start, event.title.casefold()))
    except Exception as error:
        # Invalid third-party feed data should not crash the order manager.
        if isinstance(error, CalendarError):
            raise
        raise CalendarError("This calendar feed could not be read. Check the calendar or try refreshing.") from None


class CalendarSettings:
    """Keep the private iCal address separate from ordinary shop records."""

    def __init__(self, filename=None):
        self.filename = Path(filename) if filename else Path.home() / ".tailorflow" / "calendar.json"

    def load(self):
        defaults = {"url": "", "timezone": "Australia/Sydney"}
        if not self.filename.exists():
            return defaults
        try:
            data = json.loads(self.filename.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError
            return {key: str(data.get(key, default)) for key, default in defaults.items()}
        except (OSError, ValueError, TypeError):
            raise CalendarError("Calendar settings could not be read. Reconnect in Calendar settings.") from None

    def save(self, url, timezone_name):
        if url:
            validate_feed_url(url)
            calendar_timezone(timezone_name)
        temporary = self.filename.with_suffix(".tmp")
        try:
            self.filename.parent.mkdir(parents=True, exist_ok=True)
            with temporary.open("w", encoding="utf-8") as file:
                if os.name != "nt":
                    os.chmod(temporary, 0o600)
                json.dump({"url": url.strip(), "timezone": timezone_name.strip()}, file)
            temporary.replace(self.filename)
        except OSError:
            raise CalendarError("Calendar settings could not be saved on this computer.") from None
