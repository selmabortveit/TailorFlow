"""SQLite storage. User-supplied values always use SQL parameters."""

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from models import OrderFinance

CUSTOMER_FIELDS = ("name", "phone", "email", "neck_cm", "chest_cm", "waist_cm", "jacket_size",
                   "trouser_size", "shirt_size", "shirt_brand", "suit_brand", "style", "colour", "occasion", "notes")
ORDER_FIELDS = ("customer_id", "garment", "service", "occasion", "suit_brand", "style", "colour",
                "jacket_size", "trouser_size", "shirt_size", "shirt_brand", "tie", "pocket_square", "cufflinks", "other",
                "visit_date", "pickup_date", "return_date", "total_cents", "status", "notes")
STOCK_FIELDS = ("barcode", "name", "kind", "category", "brand", "size", "colour", "quantity", "quantity_out",
                "price_cents", "location", "notes")
APPOINTMENT_FIELDS = ("customer_id", "title", "day", "start_time", "end_time", "location", "notes")


class ShopRepository:
    """Keep all SQL in one place, with transactions for related changes."""

    def __init__(self, filename):
        self.filename = Path(filename)
        self.filename.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def connect(self):
        connection = sqlite3.connect(self.filename, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def initialise(self, with_demo=True):
        with self.connect() as db:
            db.executescript(Path(__file__).with_name("schema.sql").read_text(encoding="utf-8"))
            if db.execute("SELECT 1 FROM settings WHERE key = 'initialised'").fetchone():
                return
            if with_demo:
                self._seed(db)
            db.execute("INSERT INTO settings VALUES ('initialised', 'yes')")

    @staticmethod
    def _insert(db, table, fields, values):
        # table/fields are internal constants, never request data.
        columns = ", ".join(fields)
        placeholders = ", ".join("?" for _ in fields)
        return db.execute(f"INSERT INTO {table} ({columns}) VALUES ({placeholders})",
                          [values.get(field, "") for field in fields]).lastrowid

    @staticmethod
    def _save(db, table, fields, values, record_id=None):
        if record_id is None:
            return ShopRepository._insert(db, table, fields, values)
        assignments = ", ".join(f"{field} = ?" for field in fields)
        result = db.execute(f"UPDATE {table} SET {assignments} WHERE id = ?",
                            [values.get(field, "") for field in fields] + [record_id])
        if not result.rowcount:
            raise ValueError("This record no longer exists.")
        return record_id

    def query(self, sql, parameters=()):
        with self.connect() as db:
            return [dict(row) for row in db.execute(sql, parameters).fetchall()]

    def customer(self, record_id):
        rows = self.query("SELECT * FROM customers WHERE id = ?", (record_id,))
        return rows[0] if rows else None

    def customers(self, search=""):
        pattern = f"%{search}%"
        return self.query("""SELECT c.*, COUNT(o.id) AS order_count,
            COALESCE(SUM(o.status NOT IN ('Completed','Cancelled','Returned')), 0) AS active_count
            FROM customers c LEFT JOIN orders o ON o.customer_id = c.id
            WHERE c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?
            GROUP BY c.id ORDER BY c.name COLLATE NOCASE""", (pattern, pattern, pattern))

    def save_customer(self, values, record_id=None):
        with self.connect() as db:
            return self._save(db, "customers", CUSTOMER_FIELDS, values, record_id)

    def delete_customer(self, record_id):
        with self.connect() as db:
            db.execute("DELETE FROM customers WHERE id = ?", (record_id,))

    def orders(self, customer_id=None):
        sql = "SELECT * FROM order_details"
        parameters = ()
        if customer_id is not None:
            sql += " WHERE customer_id = ?"
            parameters = (customer_id,)
        rows = self.query(sql + " ORDER BY id DESC", parameters)
        for row in rows:
            row["finance"] = OrderFinance(row["total_cents"], row["paid_cents"])
        return rows

    def order(self, record_id):
        rows = self.query("SELECT * FROM order_details WHERE id = ?", (record_id,))
        if not rows:
            return None
        row = rows[0]
        row["finance"] = OrderFinance(row["total_cents"], row["paid_cents"])
        return row

    def save_order(self, values, record_id=None, initial_paid=0):
        with self.connect() as db:
            record_id = self._save(db, "orders", ORDER_FIELDS, values, record_id)
            if initial_paid:
                db.execute("INSERT INTO payments(order_id, amount_cents, note) VALUES (?, ?, ?)",
                           (record_id, initial_paid, "Initial payment"))
            return record_id

    def set_status(self, record_id, status):
        with self.connect() as db:
            db.execute("UPDATE orders SET status = ? WHERE id = ?", (status, record_id))

    def record_payment(self, record_id, amount_cents, note=""):
        with self.connect() as db:
            db.execute("INSERT INTO payments(order_id, amount_cents, note) VALUES (?, ?, ?)",
                       (record_id, amount_cents, note))

    def delete_order(self, record_id):
        with self.connect() as db:
            db.execute("DELETE FROM orders WHERE id = ?", (record_id,))

    def appointments(self):
        return self.query("""SELECT a.*, c.name AS customer_name FROM appointments a
            LEFT JOIN customers c ON a.customer_id = c.id ORDER BY day, start_time""")

    def save_appointment(self, values, record_id=None):
        with self.connect() as db:
            return self._save(db, "appointments", APPOINTMENT_FIELDS, values, record_id)

    def delete_appointment(self, record_id):
        with self.connect() as db:
            db.execute("DELETE FROM appointments WHERE id = ?", (record_id,))

    def stock(self):
        rows = self.query("SELECT * FROM stock_items ORDER BY name COLLATE NOCASE")
        for row in rows:
            row["available"] = row["quantity"] - row["quantity_out"]
        return rows

    def stock_item(self, record_id):
        return next((row for row in self.stock() if row["id"] == record_id), None)

    def save_stock(self, values, record_id=None):
        with self.connect() as db:
            return self._save(db, "stock_items", STOCK_FIELDS, values, record_id)

    def stock_action(self, record_id, action):
        statements = {
            "checkout": "UPDATE stock_items SET quantity_out = quantity_out + 1 WHERE id = ? AND kind = 'Hire' AND quantity_out < quantity",
            "return": "UPDATE stock_items SET quantity_out = quantity_out - 1 WHERE id = ? AND kind = 'Hire' AND quantity_out > 0",
            "sell": "UPDATE stock_items SET quantity = quantity - 1 WHERE id = ? AND kind = 'Sale' AND quantity > 0",
        }
        if action not in statements:
            raise ValueError("Choose a valid stock action.")
        with self.connect() as db:
            if not db.execute(statements[action], (record_id,)).rowcount:
                raise ValueError("That quantity change is not available for this item.")
            db.execute("INSERT INTO stock_events(stock_id, action) VALUES (?, ?)", (record_id, action))

    def delete_stock(self, record_id):
        with self.connect() as db:
            if not db.execute("DELETE FROM stock_items WHERE id = ? AND quantity_out = 0", (record_id,)).rowcount:
                raise ValueError("Return the pieces on hire before deleting this stock item.")

    def backup(self):
        tables = ("customers", "orders", "payments", "order_events", "appointments", "stock_items", "stock_events")
        # One read transaction gives the export a consistent snapshot.
        with self.connect() as db:
            db.execute("BEGIN")
            return {"format": "tailorflow-web-1", **{
                table: [dict(row) for row in db.execute(f"SELECT * FROM {table}")] for table in tables}}

    def _seed(self, db):
        """Fictional examples only; loaded once from readable JSON."""
        data = json.loads(Path(__file__).with_name("demo.json").read_text(encoding="utf-8"))
        today = datetime.now(ZoneInfo("Australia/Sydney")).date()
        for customer in data["customers"]:
            self._insert(db, "customers", CUSTOMER_FIELDS, customer)
        for order in data["orders"]:
            order["visit_date"] = (today - timedelta(days=2)).isoformat()
            order["pickup_date"] = (today + timedelta(days=order.pop("pickup_in_days"))).isoformat()
            offset = order.pop("return_in_days", None)
            order["return_date"] = (today + timedelta(days=offset)).isoformat() if offset is not None else ""
            order_id = self._insert(db, "orders", ORDER_FIELDS, order)
            if order.get("paid_cents"):
                db.execute("INSERT INTO payments(order_id, amount_cents, note) VALUES (?, ?, 'Initial payment')",
                           (order_id, order["paid_cents"]))
        for item in data["stock"]:
            self._insert(db, "stock_items", STOCK_FIELDS, item)
        for appointment in data["appointments"]:
            appointment["day"] = (today + timedelta(days=appointment.pop("day_offset", 0))).isoformat()
            self._insert(db, "appointments", APPOINTMENT_FIELDS, appointment)
