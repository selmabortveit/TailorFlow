"""Small, testable business rules. No HTML or database connections here."""

from datetime import date
from decimal import Decimal, InvalidOperation


class OrderFinance:
    """Calculate what a client has paid and what remains, using integer cents."""

    def __init__(self, total_cents, paid_cents):
        self.total_cents = total_cents
        self.paid_cents = paid_cents

    @property
    def balance_cents(self):
        return self.total_cents - self.paid_cents

    @property
    def label(self):
        if self.balance_cents == 0:
            return "Paid in full" if self.total_cents else "No payment due"
        return "Part paid" if self.paid_cents else "Unpaid"

    @property
    def tone(self):
        return "green" if self.balance_cents == 0 else "amber"

    @staticmethod
    def to_cents(value, label="Amount"):
        """Reject invalid or overly precise amounts instead of silently rounding."""
        try:
            amount = Decimal(str(value or "0").strip())
            if not amount.is_finite() or amount < 0 or amount > 9999999:
                raise ValueError
            if amount != amount.quantize(Decimal("0.01")):
                raise ValueError
            return int(amount * 100)
        except (ValueError, InvalidOperation):
            raise ValueError(f"{label} must be a positive amount or zero, with at most two decimal places.") from None


def valid_date(value, label="Date", required=False):
    if not value and not required:
        return ""
    try:
        return date.fromisoformat(value).isoformat()
    except (ValueError, TypeError):
        raise ValueError(f"Choose a valid {label.lower()}.") from None


def measurement(value, label):
    if not value:
        return ""
    try:
        number = Decimal(value)
        if not number.is_finite() or not 0 < number <= 400:
            raise ValueError
    except (ValueError, InvalidOperation):
        raise ValueError(f"{label} must be between 0 and 400 cm.") from None
    return value


def status_tone(status):
    if status in ("Ready for pickup", "Completed", "Returned"):
        return "green"
    if status in ("Awaiting items", "Waiting on hire return", "Not yet packed"):
        return "amber"
    if status == "Cancelled":
        return "red"
    return "gold"
