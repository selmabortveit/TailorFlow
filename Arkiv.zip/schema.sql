-- SQLite creates the tables once. Existing records are never reset on startup.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL CHECK (length(trim(name)) > 0),
    phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
    neck_cm TEXT NOT NULL DEFAULT '', chest_cm TEXT NOT NULL DEFAULT '', waist_cm TEXT NOT NULL DEFAULT '',
    jacket_size TEXT NOT NULL DEFAULT '', trouser_size TEXT NOT NULL DEFAULT '',
    shirt_size TEXT NOT NULL DEFAULT '', shirt_brand TEXT NOT NULL DEFAULT '',
    suit_brand TEXT NOT NULL DEFAULT '', style TEXT NOT NULL DEFAULT '',
    colour TEXT NOT NULL DEFAULT '', occasion TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    garment TEXT NOT NULL CHECK (length(trim(garment)) > 0),
    service TEXT NOT NULL DEFAULT 'Formal hire', occasion TEXT NOT NULL DEFAULT '',
    suit_brand TEXT NOT NULL DEFAULT '', style TEXT NOT NULL DEFAULT '', colour TEXT NOT NULL DEFAULT '',
    jacket_size TEXT NOT NULL DEFAULT '', trouser_size TEXT NOT NULL DEFAULT '',
    shirt_size TEXT NOT NULL DEFAULT '', shirt_brand TEXT NOT NULL DEFAULT '',
    tie TEXT NOT NULL DEFAULT '', pocket_square TEXT NOT NULL DEFAULT '',
    cufflinks TEXT NOT NULL DEFAULT '', other TEXT NOT NULL DEFAULT '',
    visit_date TEXT NOT NULL, pickup_date TEXT NOT NULL DEFAULT '', return_date TEXT NOT NULL DEFAULT '',
    total_cents INTEGER NOT NULL DEFAULT 0 CHECK (total_cents >= 0),
    status TEXT NOT NULL DEFAULT 'New consultation' CHECK (status IN (
        'New consultation', 'Not yet packed', 'Awaiting items', 'Waiting on hire return', 'In alterations',
        'Ready for pickup', 'Collected', 'Returned', 'Completed', 'Cancelled'
    )),
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- The database logs each status change, including the initial status.
CREATE TRIGGER IF NOT EXISTS order_created AFTER INSERT ON orders
BEGIN INSERT INTO order_events(order_id, status) VALUES (NEW.id, NEW.status); END;
CREATE TRIGGER IF NOT EXISTS order_status_changed AFTER UPDATE OF status ON orders
WHEN NEW.status <> OLD.status
BEGIN INSERT INTO order_events(order_id, status) VALUES (NEW.id, NEW.status); END;

-- Integer cents avoid floating-point rounding in prices and payments.
CREATE TRIGGER IF NOT EXISTS prevent_overpayment BEFORE INSERT ON payments
WHEN NEW.amount_cents + COALESCE((SELECT SUM(amount_cents) FROM payments WHERE order_id = NEW.order_id), 0)
     > (SELECT total_cents FROM orders WHERE id = NEW.order_id)
BEGIN SELECT RAISE(ABORT, 'Payment exceeds the remaining balance.'); END;
CREATE TRIGGER IF NOT EXISTS prevent_price_below_paid BEFORE UPDATE OF total_cents ON orders
WHEN NEW.total_cents < COALESCE((SELECT SUM(amount_cents) FROM payments WHERE order_id = NEW.id), 0)
BEGIN SELECT RAISE(ABORT, 'Total cannot be less than payments already recorded.'); END;

CREATE VIEW IF NOT EXISTS order_details AS
SELECT o.*, printf('TF-%04d', 1000 + o.id) AS order_no,
       c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email,
       COALESCE((SELECT SUM(p.amount_cents) FROM payments p WHERE p.order_id = o.id), 0) AS paid_cents
FROM orders o JOIN customers c ON c.id = o.customer_id;

CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
    title TEXT NOT NULL CHECK (length(trim(title)) > 0),
    day TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL,
    location TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
    CHECK (end_time > start_time)
);

CREATE TABLE IF NOT EXISTS stock_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barcode TEXT NOT NULL UNIQUE CHECK (length(trim(barcode)) > 0),
    name TEXT NOT NULL CHECK (length(trim(name)) > 0),
    kind TEXT NOT NULL CHECK (kind IN ('Hire', 'Sale')),
    category TEXT NOT NULL DEFAULT 'Suit', brand TEXT NOT NULL DEFAULT '',
    size TEXT NOT NULL DEFAULT '', colour TEXT NOT NULL DEFAULT '',
    quantity INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    quantity_out INTEGER NOT NULL DEFAULT 0 CHECK (quantity_out >= 0 AND quantity_out <= quantity),
    price_cents INTEGER NOT NULL DEFAULT 0 CHECK (price_cents >= 0),
    location TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
    CHECK (kind = 'Hire' OR quantity_out = 0)
);

CREATE TABLE IF NOT EXISTS stock_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stock_id INTEGER NOT NULL REFERENCES stock_items(id) ON DELETE CASCADE,
    action TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS orders_pickup ON orders(pickup_date);
CREATE INDEX IF NOT EXISTS appointments_day ON appointments(day);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
