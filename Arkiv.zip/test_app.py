"""Integration tests use the real routes, transactions and HTML templates."""

import json
import sqlite3
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

from app import create_app, make_ical
from calendar_feed import CalendarError, calendar_packages_available, parse_feed, validate_feed_url
from models import OrderFinance


class ShopTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.config = dict(TESTING=True, SECRET_KEY="test-only-key", DATABASE=self.folder.name + "/shop.sqlite3",
                           CALENDAR_DIR=self.folder.name)
        self.app = create_app(self.config)
        self.client = self.app.test_client()
        self.repo = self.app.extensions["shop"]
        self.client.get("/clients/new")
        with self.client.session_transaction() as session:
            self.csrf = session["csrf"]

    def tearDown(self):
        self.folder.cleanup()

    def post(self, path, data=None, follow=True):
        return self.client.post(path, data={**(data or {}), "csrf_token": self.csrf}, follow_redirects=follow)

    def order_data(self, **changes):
        values = dict(customer_id="1", garment="Dark navy GM Hanna suit", service="Formal hire", occasion="Wedding",
                      colour="Dark navy", suit_brand="GM Hanna", style="Shawl lapel", status="Not yet packed",
                      visit_date="2026-10-30", pickup_date="2026-11-04", return_date="2026-11-10",
                      price="260.00", initial_paid="130.00", tie="Black silk", pocket_square="White linen", cufflinks="Silver", other="Cummerbund")
        values.update(changes)
        return values

    def test_all_main_pages_and_assets(self):
        for path in ("/", "/clients", "/clients/1", "/clients/new", "/clients/1/edit", "/orders", "/orders/1",
                     "/orders/new", "/orders/new?customer_id=1", "/orders/1/edit", "/stock", "/stock/new", "/stock/1/edit",
                     "/calendar", "/calendar?month=2026-11", "/appointments/new", "/appointments/1/edit",
                     "/calendar/connect", "/orders/1/delete", "/static/styles.css", "/static/suit.svg"):
            with self.subTest(path=path):
                with self.client.get(path) as response:
                    self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.get("/orders/999").status_code, 404)
        self.assertEqual(self.client.get("/not-a-page").status_code, 404)

    def test_new_consultation_does_not_create_order(self):
        before = len(self.repo.orders())
        response = self.post("/clients/new", dict(name="Alex Morgan", neck_cm="39.5", chest_cm="100", waist_cm="84",
                                                  suit_brand="Gibson", shirt_brand="No shirt", jacket_size="40R"))
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Alex Morgan", response.data)
        self.assertEqual(len(self.repo.orders()), before)
        self.assertEqual(self.repo.customers("Alex")[0]["neck_cm"], "39.5")

    def test_profile_edits_are_visible_despite_existing_orders(self):
        values = dict(self.repo.customer(1), jacket_size="44R", shirt_brand="No shirt")
        self.post("/clients/1/edit", values)
        response = self.client.get("/clients/1")
        self.assertIn(b"44R", response.data)
        self.assertIn(b"No shirt", response.data)
        self.assertEqual(self.repo.order(1)["jacket_size"], "42R")

    def test_client_validation_and_html_escaping(self):
        self.assertEqual(self.post("/clients/new", {"name":"", "neck_cm":"42"}).status_code, 400)
        self.assertEqual(self.post("/clients/new", {"name":"Alex", "neck_cm":"NaN"}).status_code, 400)
        self.assertEqual(self.post("/clients/new", {"name":"Alex", "email":"bad address"}).status_code, 400)
        response = self.post("/clients/new", {"name":"<script>example</script>"})
        self.assertIn(b"&lt;script&gt;example&lt;/script&gt;", response.data)
        self.assertNotIn(b"<script>example</script>", response.data)

    def test_order_accessories_and_partial_payment(self):
        response = self.post("/orders/new", self.order_data())
        self.assertEqual(response.status_code, 200)
        order = self.repo.orders()[0]
        self.assertEqual(order["tie"], "Black silk")
        self.assertEqual(order["pocket_square"], "White linen")
        self.assertEqual(order["cufflinks"], "Silver")
        self.assertEqual(order["other"], "Cummerbund")
        self.assertEqual(order["finance"].balance_cents, 13000)
        self.assertEqual(order["finance"].label, "Part paid")
        for label in (b"Tie", b"Pocket square", b"Cufflinks", b"Other"):
            self.assertIn(label, response.data)
        self.assertNotIn(b"Accessory 1", response.data)

    def test_order_default_description_and_blank_dates(self):
        response = self.post("/orders/new", self.order_data(garment="", pickup_date="", return_date="", initial_paid="0"))
        self.assertEqual(response.status_code, 200)
        order = self.repo.orders()[0]
        self.assertEqual(order["garment"], "Dark navy GM Hanna suit")
        self.assertEqual((order["pickup_date"], order["return_date"]), ("", ""))

    def test_invalid_dates_and_amounts_do_not_create_orders(self):
        before = len(self.repo.orders())
        for changes in ({"pickup_date":"2026-02-30"}, {"return_date":"2026-11-01"}, {"price":"NaN"},
                        {"price":"-1"}, {"price":"10.001"}, {"initial_paid":"999"}, {"customer_id":"999"}):
            with self.subTest(changes=changes):
                self.assertEqual(self.post("/orders/new", self.order_data(**changes)).status_code, 400)
                self.assertEqual(len(self.repo.orders()), before)

    def test_payment_cannot_exceed_balance_and_finishes_exactly(self):
        self.post("/orders/2/payment", {"amount":"130.01"})
        self.assertEqual(self.repo.order(2)["paid_cents"], 13000)
        self.post("/orders/2/payment", {"amount":"130.00", "note":"Paid on pickup"})
        finance = self.repo.order(2)["finance"]
        self.assertEqual(finance.balance_cents, 0)
        self.assertEqual(finance.label, "Paid in full")
        self.post("/orders/2/payment", {"amount":"0.01"})
        self.assertEqual(self.repo.order(2)["paid_cents"], 26000)

    def test_database_itself_rejects_overpayment_and_lower_price(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.repo.record_payment(2, 13001)
        self.assertEqual(self.repo.order(2)["paid_cents"], 13000)
        values = dict(self.repo.order(2), total_cents=12000)
        with self.assertRaises(sqlite3.IntegrityError):
            self.repo.save_order(values, 2)
        self.assertEqual(self.repo.order(2)["total_cents"], 26000)

    def test_status_history_and_dashboard_counts(self):
        self.post("/orders/2/status", {"status":"In alterations"})
        self.post("/orders/2/status", {"status":"In alterations"})
        events = self.repo.query("SELECT * FROM order_events WHERE order_id = 2")
        self.assertEqual([event["status"] for event in events], ["Ready for pickup", "In alterations"])
        self.post("/orders/2/status", {"status":"Collected"})
        page = self.client.get("/").data
        self.assertIn(b"Hire returns due", page)
        self.assertIn(b"Black formal hire package", page)
        self.assertEqual(self.post("/orders/2/status", {"status":"invented"}).status_code, 400)

    def test_order_edit_keeps_payment_history(self):
        response = self.post("/orders/2/edit", self.order_data(price="300", initial_paid="200", garment="Updated suit"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.repo.order(2)["paid_cents"], 13000)
        self.assertEqual(self.repo.order(2)["total_cents"], 30000)

    def test_print_form_uses_the_selected_orders_dates_and_sizes(self):
        order = dict(self.repo.order(2), pickup_date="2026-10-28", return_date="2026-11-03",
                     jacket_size="ORDER-38R", trouser_size="ORDER-32", shirt_size="ORDER-39",
                     tie="Navy knitted tie", pocket_square="White linen", cufflinks="Silver pair",
                     other="Cummerbund", notes="Check sleeve length before packing.")
        self.repo.save_order(order, 2)
        customer = dict(self.repo.customer(2), jacket_size="CURRENT-46L", neck_cm="39", chest_cm="96",
                        waist_cm="87", notes="PRIVATE CLIENT NOTE")
        self.repo.save_customer(customer, 2)
        page = self.client.get("/orders/2/print").data
        for value in (b"Emily Roberts", b"TF-1002", b"28/10/2026", b"03/11/2026", b"Pickup date", b"Drop-off date",
                      b"ORDER-38R", b"ORDER-32", b"ORDER-39", b"Navy knitted tie", b"White linen", b"Silver pair",
                      b"Cummerbund", b"Check sleeve length", b"$130.00", b"Final check"):
            self.assertIn(value, page)
        self.assertNotIn(b"CURRENT-46L", page)
        self.assertNotIn(b"PRIVATE CLIENT NOTE", page)
        self.assertNotIn(b"Status history", page)
        self.assertNotIn(b"Payment history", page)

    def test_print_form_leaves_unagreed_dates_and_accessories_blank(self):
        order = dict(self.repo.order(2), pickup_date="", return_date="", tie="", pocket_square="", cufflinks="", other="")
        self.repo.save_order(order, 2)
        page = self.client.get("/orders/2/print")
        self.assertEqual(page.status_code, 200)
        self.assertEqual(page.data.count(b"To be agreed"), 2)
        for label in (b"Tie", b"Pocket square", b"Cufflinks", b"Other"):
            self.assertIn(label, page.data)

    def test_print_action_is_on_order_and_does_not_change_records(self):
        self.assertIn(b'/orders/2/print', self.client.get("/orders/2").data)
        self.assertNotIn(b"Print form", self.client.get("/clients/2").data)
        before = self.repo.backup()
        self.assertEqual(self.client.get("/orders/2/print").status_code, 200)
        self.assertEqual(self.repo.backup(), before)
        self.assertEqual(self.client.get("/orders/999/print").status_code, 404)

    def test_print_form_escapes_user_entered_text(self):
        order = dict(self.repo.order(2), notes="<script>example</script>", garment='<img src=x onerror="alert(1)">')
        self.repo.save_order(order, 2)
        page = self.client.get("/orders/2/print").data
        self.assertIn(b"&lt;script&gt;example&lt;/script&gt;", page)
        self.assertNotIn(b"<script>example</script>", page)
        self.assertNotIn(b'<img src=x onerror="alert(1)">', page)

    def test_filters(self):
        page = self.client.get("/orders?status=Awaiting+items").data
        self.assertIn(b"Grey business suit", page)
        self.assertNotIn(b"Navy wedding suit", page)
        page = self.client.get("/orders?q=TF-1002").data
        self.assertIn(b"Black formal hire package", page)
        self.assertNotIn(b"Navy wedding suit", page)
        page = self.client.get("/stock?kind=Sale&category=Shirt").data
        self.assertIn(b"White formal shirt", page)
        self.assertNotIn(b"Black dinner suit", page)
        self.assertIn(b"Black dinner suit", self.client.get("/stock?q=HIRE-0001").data)

    def test_stock_actions_protect_quantities(self):
        self.post("/stock/1/action", {"action":"checkout"})
        self.assertEqual(self.repo.stock_item(1)["quantity_out"], 3)
        self.post("/stock/1/action", {"action":"return"})
        self.assertEqual(self.repo.stock_item(1)["quantity_out"], 2)
        for _ in range(6):
            self.post("/stock/1/action", {"action":"checkout"})
        self.assertEqual(self.repo.stock_item(1)["available"], 0)
        self.post("/stock/6/action", {"action":"sell"})
        self.assertEqual(self.repo.stock_item(6)["quantity"], 0)
        self.assertEqual(self.post("/stock/1/delete").status_code, 400)
        self.post("/stock/4/action", {"action":"sell"})
        self.assertEqual(self.repo.stock_item(4)["quantity"], 2)

    def test_new_stock_and_duplicate_code(self):
        data = dict(name="Test jacket", barcode="JACKET-1", kind="Hire", category="Jacket", quantity="2", quantity_out="0", price="150")
        self.assertEqual(self.post("/stock/new", data).status_code, 200)
        self.assertEqual(self.post("/stock/new", data).status_code, 400)
        data.update(barcode="JACKET-2", quantity_out="3")
        self.assertEqual(self.post("/stock/new", data).status_code, 400)

    def test_appointment_creation_edit_and_calendar(self):
        values = dict(title="Alex · Fitting", day="2026-11-02", start_time="10:00", end_time="10:30", customer_id="1")
        self.assertEqual(self.post("/appointments/new", values).status_code, 200)
        self.assertIn(b"Alex", self.client.get("/calendar?month=2026-11").data)
        record_id = self.repo.query("SELECT id FROM appointments WHERE title = ?", (values["title"],))[0]["id"]
        values.update(start_time="11:00", end_time="10:00")
        self.assertEqual(self.post(f"/appointments/{record_id}/edit", values).status_code, 400)
        self.assertEqual(self.repo.query("SELECT start_time FROM appointments WHERE id = ?", (record_id,))[0]["start_time"], "10:00")
        self.post(f"/appointments/{record_id}/delete")
        self.assertFalse(self.repo.query("SELECT * FROM appointments WHERE id = ?", (record_id,)))

    def test_csrf_blocks_unrequested_changes(self):
        before = self.repo.order(1)["status"]
        response = self.client.post("/orders/1/status", data={"status":"Completed"})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(self.repo.order(1)["status"], before)

    def test_client_deletion_protects_orders(self):
        self.assertEqual(self.post("/clients/1/delete").status_code, 400)
        self.assertIsNotNone(self.repo.customer(1))
        self.post("/orders/1/delete")
        self.assertIsNone(self.repo.order(1))
        self.assertFalse(self.repo.query("SELECT * FROM payments WHERE order_id = 1"))
        self.assertFalse(self.repo.query("SELECT * FROM order_events WHERE order_id = 1"))
        self.assertIsNotNone(self.repo.customer(1))

    def test_export_and_persistence_without_reseeding(self):
        data = json.loads(self.client.get("/export.json").data)
        self.assertEqual(data["format"], "tailorflow-web-1")
        self.assertEqual(len(data["customers"]), 3)
        self.assertNotIn("calendar.json", json.dumps(data))
        self.post("/orders/1/status", {"status":"Completed"})
        other = create_app(self.config).extensions["shop"]
        self.assertEqual(len(other.orders()), 3)
        self.assertEqual(other.order(1)["status"], "Completed")

    def test_corrupt_calendar_configuration_does_not_break_core(self):
        Path(self.folder.name, "calendar.json").write_text("not json")
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(self.client.get("/calendar").status_code, 200)

    def test_absent_optional_calendar_packages_leave_core_usable(self):
        with patch("app.calendar_packages_available", return_value=False):
            response = self.post("/calendar/connect", {"url":"https://calendar.google.com/calendar/ical/test/private-a/basic.ics"})
            self.assertEqual(response.status_code, 400)
            self.assertIn(b"not installed", response.data)
            self.assertEqual(self.client.get("/orders").status_code, 200)

    @unittest.skipUnless(calendar_packages_available(), "Optional calendar packages are not installed")
    def test_calendar_connection_retains_cache_after_network_failure(self):
        content = b"BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nUID:test\r\nDTSTART;VALUE=DATE:20261102\r\nDTEND;VALUE=DATE:20261103\r\nSUMMARY:Fixture visit\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n"
        address = "https://calendar.google.com/calendar/ical/test/private-test-secret/basic.ics"
        with patch("app.download_feed", return_value=content):
            self.assertEqual(self.post("/calendar/connect", {"url":address}).status_code, 200)
        cache = Path(self.folder.name, "google-calendar.ics")
        self.assertEqual(cache.read_bytes(), content)
        with patch("app.download_feed", side_effect=CalendarError("Could not load Google Calendar.")):
            self.assertEqual(self.post("/calendar/refresh").status_code, 200)
        self.assertEqual(cache.read_bytes(), content)
        self.assertNotIn(b"private-test-secret", self.client.get("/calendar/connect").data)
        self.assertNotIn(b"private-test-secret", self.client.get("/export.json").data)
        self.post("/calendar/disconnect")
        self.assertFalse(cache.exists())

    def test_empty_mode_does_not_erase_existing_records(self):
        other = create_app({**self.config, "SEED_DEMO":False})
        self.assertEqual(len(other.extensions["shop"].customers()), 3)
        with tempfile.TemporaryDirectory() as folder:
            empty = create_app({**self.config, "DATABASE":folder + "/empty.sqlite3", "CALENDAR_DIR":folder, "SEED_DEMO":False})
            self.assertEqual(empty.extensions["shop"].customers(), [])
            for path in ("/", "/orders/new", "/stock", "/calendar", "/clients"):
                self.assertEqual(empty.test_client().get(path).status_code, 200)


class CalendarAndMoneyTests(unittest.TestCase):
    def test_money_precision(self):
        self.assertEqual(OrderFinance.to_cents("0.10"), 10)
        self.assertEqual(OrderFinance.to_cents("12.34"), 1234)
        for value in ("NaN", "Infinity", "-1", "0.001", "abc"):
            with self.assertRaises(ValueError):
                OrderFinance.to_cents(value)

    def test_calendar_address_validation(self):
        self.assertTrue(validate_feed_url("https://calendar.google.com/calendar/ical/test/private-a/basic.ics"))
        for url in ("http://calendar.google.com/calendar/ical/a/basic.ics", "https://example.com/basic.ics", "https://calendar.google.com.evil.test/calendar/ical/a/basic.ics"):
            with self.assertRaises(CalendarError):
                validate_feed_url(url)

    @unittest.skipUnless(calendar_packages_available(), "Optional calendar packages are not installed")
    def test_ics_export_round_trip_with_unicode_and_dst(self):
        import icalendar
        entry = dict(day="2026-11-02", time="10:00", end_time="10:30", title="Fitting, Selma Børtveit; " * 8, uid="fixture")
        content = make_ical([entry], ZoneInfo("Australia/Sydney"))
        self.assertTrue(all(len(line.encode()) <= 75 for line in content.split("\r\n")))
        event = icalendar.Calendar.from_ical(content).walk("VEVENT")[0]
        self.assertEqual(str(event["SUMMARY"]), entry["title"])
        self.assertEqual(event.decoded("DTSTART").hour, 23)  # 10 am Sydney is 11 pm UTC the previous day.
        self.assertEqual(event.decoded("DTSTART").day, 1)

    @unittest.skipUnless(calendar_packages_available(), "Optional calendar packages are not installed")
    def test_recurring_and_all_day_google_entries(self):
        content = b"BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nUID:weekly\r\nDTSTART;TZID=Australia/Sydney:20261026T100000\r\nDTEND;TZID=Australia/Sydney:20261026T103000\r\nRRULE:FREQ=WEEKLY;COUNT=3\r\nSUMMARY:Suit fitting\r\nEND:VEVENT\r\nBEGIN:VEVENT\r\nUID:all-day\r\nDTSTART;VALUE=DATE:20261102\r\nDTEND;VALUE=DATE:20261103\r\nSUMMARY:Shop visit\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n"
        events = parse_feed(content, date(2026, 11, 1), date(2026, 11, 8))
        self.assertEqual(len(events), 2)
        self.assertEqual(sum(event.all_day for event in events), 1)
        self.assertEqual(next(event for event in events if not event.all_day).time_label(date(2026, 11, 2)), "10:00")


if __name__ == "__main__":
    unittest.main()
